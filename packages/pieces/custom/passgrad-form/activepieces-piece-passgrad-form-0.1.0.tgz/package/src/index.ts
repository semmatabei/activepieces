import { createPiece, PieceCategory } from "@activepieces/pieces-framework";
import { passgradAuth } from "./lib/common";
import { newSubmission } from "./lib/triggers/new-submission";
import { getSubmission } from "./lib/actions/get-submission";

export const passgradForm = createPiece({
  displayName: "Passgrad Form",
  description:
    "Collect structured data via Passgrad forms. Trigger flows on new submissions, or retrieve submission data mid-flow.",
  logoUrl: "https://cdn.passgrad.id/logos/passgrad-form.png",
  minimumSupportedRelease: "0.30.0",
  categories: [PieceCategory.FORMS_AND_SURVEYS],
  authors: ["Passgrad"],
  auth: passgradAuth,
  triggers: [newSubmission],
  actions: [getSubmission],
});
