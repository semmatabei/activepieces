"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.passgradForm = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const common_1 = require("./lib/common");
const new_submission_1 = require("./lib/triggers/new-submission");
const get_submission_1 = require("./lib/actions/get-submission");
const request_submission_1 = require("./lib/actions/request-submission");
exports.passgradForm = (0, pieces_framework_1.createPiece)({
    displayName: "Passgrad Form",
    description: "Collect structured data via Passgrad forms. Trigger flows on new submissions, retrieve submissions, or pause a flow for an assigned member.",
    logoUrl: "https://cdn.passgrad.id/logos/passgrad-form.png",
    minimumSupportedRelease: "0.30.0",
    authors: ["Passgrad"],
    auth: common_1.passgradAuth,
    triggers: [new_submission_1.newSubmission],
    actions: [get_submission_1.getSubmission, request_submission_1.requestSubmission],
});
//# sourceMappingURL=index.js.map