export declare const passgradForm: import("@activepieces/pieces-framework").Piece<undefined>;
//# sourceMappingURL=index.d.ts.map