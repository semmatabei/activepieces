/** Opens a pinned Form session, pauses this run, then returns its captured data on resume. */
export declare const requestSubmission: import("@activepieces/pieces-framework").IAction<undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    actor_user_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=request-submission.d.ts.map