import { TriggerStrategy } from "@activepieces/pieces-framework";
/**
 * Trigger: New Submission
 *
 * Fires when a user submits the selected Passgrad form.
 * Uses APP_WEBHOOK strategy — onEnable registers the webhook URL
 * with Passgrad's API, onDisable removes it.
 *
 * Lifecycle:
 * 1. onEnable → POST /tenants/:tenantId/forms/:formId/triggers { webhook_url }
 * 2. User submits form → Passgrad POSTs immutable submission reference to webhook_url
 * 3. run() receives the reference → use Get Submission action to load payload
 * 4. onDisable → DELETE /v1/forms/:formId/triggers/:triggerId
 */
export declare const newSubmission: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=new-submission.d.ts.map