/**
 * Action: Get Submission
 *
 * Retrieves a specific form submission by ID.
 * Useful as a mid-flow step to read submitted data from a previous
 * form trigger, or to verify submission status.
 */
export declare const getSubmission: import("@activepieces/pieces-framework").IAction<undefined, {
    form_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    submission_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=get-submission.d.ts.map