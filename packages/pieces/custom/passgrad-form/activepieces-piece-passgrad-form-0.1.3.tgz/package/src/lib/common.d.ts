export declare const passgradAuth: undefined;
export declare const formIdProperty: import("@activepieces/pieces-framework").ShortTextProperty<true>;
//# sourceMappingURL=common.d.ts.map